<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/entypo/style.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.default.css" rel="stylesheet" type="text/css">
    <link href="assets/css/eve.css" rel="stylesheet" type="text/css" id="css-primary">
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

    <title>Evento. - Home</title>
</head>

<body class="">
<div class="page-wrapper">
	<div class="header-wrapper">
	<div class="header">		
		<div class="header-inner">
			<div class="header-top">
				<div class="container-fluid">
					<div class="header-logo">
						<a href="home.php">
							<span class="eve-logo"><i class="fa fa-edge"></i></span> 
							<strong>
								<span>Evento. </span>
							</strong>
						</a>
					</div><!-- /.header-logo -->

					<!-- /.header-toggle -->
					
					<div class="header-btn">
						<a class="btn btn-secondary" href="newevent.php">Create Event</a><!-- /.btn -->
					</div><!-- /.header-btn -->
					
					<div class="header-search">
						<ul class="nav nav-pills">
			<li class="nav-item">
			<a href="home.php" class="nav-link">Home</a>
		</li>
		<li class="nav-item"><a href="events.php" class="nav-link active ">Events</a></li>
		<li class="nav-item"><a href="contact.php" class="nav-link ">Contact</a></li>

		<li class="nav-item"><a href="index.php" class="nav-link ">Logout</a></li>
	</ul>
					</div><!-- /.header-search -->

				</div><!-- /.container-fluid -->
			</div><!-- /.header-top -->

			<!-- /.header-bottom -->
		</div><!-- /.header-inner -->
	</div><!-- /.header -->
</div><!-- /.header-wrapper -->
	
    <div class="main-wrapper">
	    <div class="main">
	        <div class="main-inner">
	        	

	            <div class="content">
	                <div class="hero hero-creative-wrapper">
	<div class="hero-creative">
<div class="container-fluid push-bottom">
	<div class="page-title">
		<h2>Latest Events</h2>

	</div><!-- /.page-title -->
		<?php
				$con=mysqli_connect("localhost","grabcar_evento","004421mm@","grabcar_evento");
				// Check connection
				if (mysqli_connect_errno())
				{
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}
				$result = mysqli_query($con,"SELECT * FROM events");
				$total_events = $result->num_rows;

?>
	<div class="row">
		<?php
		
		for ($i = 1; $i <= $total_events; $i++ ): ?>

			<div class="col-lg-3 col-xl-2 col-5">
				<div class="card">
	<div class="card-inner">
		<div class="card-image">
			<a href="event.html" style="background-image: url('assets/img/tmp/medium-1.jpg');">
				<span><i class="fa fa-search"></i></span>
			</a>

			<div class="card-actions">
				<a href="#"><i class="entypo-save"></i> <span>Save</span></a>
				<a href="#"><i class="entypo-heart"></i> <span>Like</span></a>
			</div><!-- /.card-actions -->
		</div><!-- /.card-image -->

		<div class="card-content">	
			<div class="card-date">
				
				
			<!-- /.card-date -->

			
			<?php
				$con=mysqli_connect("localhost","grabcar_evento","004421mm@","grabcar_evento");
				// Check connection
				if (mysqli_connect_errno())
				{
				echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}
				

				$result = mysqli_query($con,"SELECT eventTitle, location, day, month, year FROM events where id='$i'");

				while($row = mysqli_fetch_array($result))
				{ 
				echo "<strong>$row[day]</strong>";
				echo "<span> $row[month]</span>";	
				echo "</div>";
				echo "<h3 class=\"card-title\">";
				echo "<a href='#'>" . $row['eventTitle'] . "</a>" ;
				echo "</h3>"; 
				echo "<h4 class=\"card-subtitle\">";
				echo " <a href='#'>" . $row[location] . "</a> ";
				echo "
					
					</h4> 
					</div><!-- /.card-content -->
			</div><!-- /.card-inner -->
		</div><!-- /.card -->
					</div><!-- /.col-* -->

			";
			} 
			mysqli_close($con);	?>
		<?php endfor; ?>
		
			
		
	</div><!-- /.row -->
</div><!-- /.container-fluid -->
	            </div><!-- /.content -->
	        </div><!-- /.main-inner -->
	    </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

    
















<script src="//maps.googleapis.com/maps/api/js" type="text/javascript"></script>
<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/tether.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-typeahead/bootstrap3-typeahead.min.js"></script>
<script type="text/javascript" src="assets/libraries/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.gmap3.js"></script>
<script type="text/javascript" src="assets/js/jquery.ytplayer.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.ezmark.min.js"></script>
<script type="text/javascript" src="assets/js/eve.js"></script>
</body>
</html>