<?php
	const DB_HOST = 'localhost';
	const DB_USER = 'grabcar_evento';
	const DB_PASS = '004421mm@';
	const DB_NAME = 'grabcar_evento';
?>