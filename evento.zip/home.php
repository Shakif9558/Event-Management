<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/entypo/style.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.default.css" rel="stylesheet" type="text/css">
    <link href="assets/css/eve.css" rel="stylesheet" type="text/css" id="css-primary">
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

    <title>Evento. - Home</title>
</head>
<body class="">
<div class="page-wrapper">
	<div class="header-wrapper">
	<div class="header">		
		<div class="header-inner">
			<div class="header-top">
				<div class="container-fluid">
					<div class="header-logo">
						<a href="home.php">
							<span class="eve-logo"><i class="fa fa-edge"></i></span> 
							<strong>
								<span>Evento. </span>
							</strong>
						</a>
					</div><!-- /.header-logo -->

					<!-- /.header-toggle -->
					
					<div class="header-btn">
						<a class="btn btn-secondary" href="newevent.php">Create Event</a><!-- /.btn -->
					</div><!-- /.header-btn -->
					
					<div class="header-search">
						<ul class="nav nav-pills">
			<li class="nav-item">
			<a href="#" class="nav-link active">Home</a>
		</li>
		<li class="nav-item"><a href="events.php" class="nav-link ">Events</a></li>
		<li class="nav-item"><a href="contact.php" class="nav-link ">Contact</a></li>

		<li class="nav-item"><a href="index.php" class="nav-link ">Logout</a></li>
	</ul>
					</div><!-- /.header-search -->

				</div><!-- /.container-fluid -->
			</div><!-- /.header-top -->

			<!-- /.header-bottom -->
		</div><!-- /.header-inner -->
	</div><!-- /.header -->
</div><!-- /.header-wrapper -->
	
    <div class="main-wrapper">
	    <div class="main">
	        <div class="main-inner">
	        	

	            <div class="content">
	                <div class="hero hero-creative-wrapper">
	<div class="hero-creative">
<div class="container-fluid push-bottom">
	<div class="page-title">
		<h2>Most Popular Events</h2>

		<p>
			Explore happening events nearby you. There are a lot of events going on currently. Evento helps you to find them easily! Go to <a href="events.php"> Events</a> page for latest event.
		</p>
	</div><!-- /.page-title -->

	<div class="row">
		
			<div class="col-lg-3 col-xl-2 col-5">
				<div class="card">
	<div class="card-inner">
		<div class="card-image">
			<a href="https://www.facebook.com/events/880426348765541/" style="background-image: url('assets/img/tmp/medium-1.jpg');">
				<span><i class="fa fa-search"></i></span>
			</a>

			<div class="card-actions">
				<a href="#"><i class="entypo-save"></i> <span>Save</span></a>
				<a href="#"><i class="entypo-heart"></i> <span>Like</span></a>
			</div><!-- /.card-actions -->
		</div><!-- /.card-image -->

		<div class="card-content">	
			<div class="card-date">
				<strong>19</strong>
				<span>Apr</span>
			</div><!-- /.card-date -->

			<h3 class="card-title">
				<a href="https://www.facebook.com/events/880426348765541/">TedxMMU 2017</a>
			</h3>

			<h4 class="card-subtitle">
				<a href="#">Multimedia University</a>
			</h4>
		</div><!-- /.card-content -->
	</div><!-- /.card-inner -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
			<div class="col-lg-3 col-xl-2 col-5">
				<div class="card">
	<div class="card-inner">
		<div class="card-image">
			<a href="https://www.facebook.com/events/1322340747839388/" style="background-image: url('assets/img/tmp/medium-2.jpg');">
				<span><i class="fa fa-search"></i></span>
			</a>

			<div class="card-actions">
				<a href="#"><i class="entypo-save"></i> <span>Save</span></a>
				<a href="#"><i class="entypo-heart"></i> <span>Like</span></a>
			</div><!-- /.card-actions -->
		</div><!-- /.card-image -->

		<div class="card-content">	
			<div class="card-date">
				<strong>27</strong>
				<span>Feb</span>
			</div><!-- /.card-date -->

			<h3 class="card-title">
				<a href="https://www.facebook.com/events/1322340747839388/">JCS Night 16/17</a>
			</h3>

			<h4 class="card-subtitle">
				<a href="#">Multimedia University</a>
			</h4>
		</div><!-- /.card-content -->
	</div><!-- /.card-inner -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
			<div class="col-lg-3 col-xl-2 col-5">
				<div class="card">
	<div class="card-inner">
		<div class="card-image">
			<a href="https://www.facebook.com/events/1798285273767730/" style="background-image: url('assets/img/tmp/medium-3.jpg');">
				<span><i class="fa fa-search"></i></span>
			</a>

			<div class="card-actions">
				<a href="#"><i class="entypo-save"></i> <span>Save</span></a>
				<a href="#"><i class="entypo-heart"></i> <span>Like</span></a>
			</div><!-- /.card-actions -->
		</div><!-- /.card-image -->

		<div class="card-content">	
			<div class="card-date">
				<strong>7</strong>
				<span>Apr</span>
			</div><!-- /.card-date -->

			<h3 class="card-title">
				<a href="https://www.facebook.com/events/1798285273767730/">Tech Talk Thurs 8</a>
			</h3>

			<h4 class="card-subtitle">
				<a href="#">Multimedia University</a>
			</h4>
		</div><!-- /.card-content -->
	</div><!-- /.card-inner -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
			<div class="col-lg-3 col-xl-2 col-5">
				<div class="card">
	<div class="card-inner">
		<div class="card-image">
			<a href="https://www.facebook.com/events/243649986085176/" style="background-image: url('assets/img/tmp/medium-4.jpg');">
				<span><i class="fa fa-search"></i></span>
			</a>

			<div class="card-actions">
				<a href="#"><i class="entypo-save"></i> <span>Save</span></a>
				<a href="#"><i class="entypo-heart"></i> <span>Like</span></a>
			</div><!-- /.card-actions -->
		</div><!-- /.card-image -->

		<div class="card-content">	
			<div class="card-date">
				<strong>4</strong>
				<span>May</span>
			</div><!-- /.card-date -->

			<h3 class="card-title">
				<a href="https://www.facebook.com/events/243649986085176/">Megadeth LIVE</a>
			</h3>

			<h4 class="card-subtitle">
				<a href="#">Stadium Negara</a>
			</h4>
		</div><!-- /.card-content -->
	</div><!-- /.card-inner -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
			<div class="col-lg-3 col-xl-2 col-5">
				<div class="card">
	<div class="card-inner">
		<div class="card-image">
			<a href="https://www.facebook.com/events/1165065770280577/" style="background-image: url('assets/img/tmp/medium-5.jpg');">
				<span><i class="fa fa-search"></i></span>
			</a>

			<div class="card-actions">
				<a href="#"><i class="entypo-save"></i> <span>Save</span></a>
				<a href="#"><i class="entypo-heart"></i> <span>Like</span></a>
			</div><!-- /.card-actions -->
		</div><!-- /.card-image -->

		<div class="card-content">	
			<div class="card-date">
				<strong>21</strong>
				<span>Mar</span>
			</div><!-- /.card-date -->

			<h3 class="card-title">
				<a href="https://www.facebook.com/events/1165065770280577/">GoRun Taylor's</a>
			</h3>

			<h4 class="card-subtitle">
				<a href="#">Taylor's University</a>
			</h4>
		</div><!-- /.card-content -->
	</div><!-- /.card-inner -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
	</div><!-- /.row -->
</div><!-- /.container-fluid -->
	            </div><!-- /.content -->
	        </div><!-- /.main-inner -->
	    </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

    

















<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/tether.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-typeahead/bootstrap3-typeahead.min.js"></script>
<script type="text/javascript" src="assets/libraries/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.gmap3.js"></script>
<script type="text/javascript" src="assets/js/jquery.ytplayer.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.ezmark.min.js"></script>
<script type="text/javascript" src="assets/js/eve.js"></script>
</body>
</html>