<html>
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/entypo/style.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.default.css" rel="stylesheet" type="text/css">
    <link href="assets/css/eve.css" rel="stylesheet" type="text/css" id="css-primary">
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">
	<title>Evento. - login</title>
</head>
<body class ="empty-layout">
<div class="content-center">
<?php
    ob_start();

if (!isset($_POST['submit'])){
?>
<!-- The HTML login form -->
	<form method="post" action="<?=$_SERVER['PHP_SELF']?>" class="login-form">
    	<h1>Evento.</h1>



        <div class="form-group">
            <label for="login-form-username">Username</label>
            <input id="login-form-username" type="text" name="username" class="form-control" required="required" placeholder="user">
        </div><!-- /.form-group -->

        <div class="form-group">
            <label for="login-form-password">Password</label>
            <input id="login-form-password" type="password" name="password" class="form-control" required="required" placeholder="123456">
        </div><!-- /.form-group -->

    	
    	<button type="submit" name="submit" value="Login" class="btn btn-secondary pull-right">Log in</button>
    	<input type="button" onclick="location.href='register.php';"class="btn btn-secondary pull-right" value="Register" />
    </form>
    </form>
 
	
<?php
} else {
	require_once("db_const.php");
	$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	# check connection
	if ($mysqli->connect_errno) {
		echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
		exit();
	}

	$username = $_POST['username'];
	$password = $_POST['password'];

	$sql = "SELECT * from users WHERE username LIKE '{$username}' AND password LIKE '{$password}' LIMIT 1";
	$result = $mysqli->query($sql);
	if (!$result->num_rows == 1) {
		echo "<p>Invalid username/password combination</p>";
	} else {
		echo '<script type="text/javascript">';
		echo 'window.location.href="home.php";';
		echo '</script>';		
	}
}
?>


</div>		
</body>
</html>