<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/entypo/style.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.default.css" rel="stylesheet" type="text/css">
    <link href="assets/css/eve.css" rel="stylesheet" type="text/css" id="css-primary">
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

    <title>Evento. - Home</title>
</head>

<body class="">
<div class="page-wrapper">

	<div class="header-wrapper">
	<div class="header">		
		<div class="header-inner">
			<div class="header-top">
				<div class="container-fluid">
					<div class="header-logo">
						<a href="home.php">
							<span class="eve-logo"><i class="fa fa-edge"></i></span> 
							<strong>
								<span>Evento. </span>
							</strong>
						</a>
					</div><!-- /.header-logo -->

					<!-- /.header-toggle -->
					
					<div class="header-btn">
						<a class="btn btn-secondary" href="newevent.php">Create Event</a><!-- /.btn -->
					</div><!-- /.header-btn -->
					
					<div class="header-search">
						<ul class="nav nav-pills">
			<li class="nav-item">
			<a href="home.php" class="nav-link active">Home</a>
		</li>
		<li class="nav-item"><a href="events.php" class="nav-link ">Events</a></li>
		<li class="nav-item"><a href="mailto:motasimrahman@gmail.com" class="nav-link ">Contact</a></li>
		
		<li class="nav-item"><a href="index.php" class="nav-link ">Logout</a></li>
	</ul>
					</div><!-- /.header-search -->

				</div><!-- /.container-fluid -->
			</div><!-- /.header-top -->

			<!-- /.header-bottom -->
		</div><!-- /.header-inner -->
	</div><!-- /.header -->
</div><!-- /.header-wrapper -->

	<div class="main-wrapper">
	    <div class="main">
	        <div class="main-inner">
	        	
<?php
require_once("db_const.php");
if (!isset($_POST['submit'])) {
?>
	            <div class="content">
	                <div class="container">

	<form method="post" action="contact.php">		
		<fieldset>
			<legend>Contact Form</legend>		

			<div class="form-group">
				<label>Subject</label>
				<input type="text" class="form-control bordered" name="subject">
			</div><!-- /.form-group -->

			<div class="form-group">
				<label>Message</label>
				<textarea class="form-control bordered" rows="2" name="message"></textarea>
			</div><!-- /.form-group -->
		</fieldset>

		


		<div class="center">
		<button type="submit" name="submit" value="Login" class="btn btn-secondary pull-right">Send</button>
		</div><!-- /.center -->
	</form>
</div><!-- /.container-fluid -->
	            </div><!-- /.content -->
	        </div><!-- /.main-inner -->
	    </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

    <!-- /.here -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
	</div><!-- /.row -->
</div><!-- /.container-fluid -->
	            </div><!-- /.content -->
	        </div><!-- /.main-inner -->
	    </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

<?php
} else {
## connect mysql server
	$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	# check connection
	if ($mysqli->connect_errno) {
		echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
		exit();
	}
## query database
	# prepare data for insertion
	$subject	= $_POST['subject'];
	$message	= $_POST['message'];



	

	if ($exists == 1) echo "<p></p>";
	else if ($exists == 2) echo "<p></p>";
	else if ($exists == 3) echo "<p></p>";
	else {
		# insert data into mysql database
		$sql = "INSERT  INTO `contact` (`subject`, `message`) 
				VALUES ('{$subject}', '{$message}')";

		if ($mysqli->query($sql)) {
			//echo "New Record has id ".$mysqli->insert_id;
			echo "</br> </br>  <h2> &nbsp; Your message has been sent.</h2>";
		} else {
			echo "<p>MySQL error no {$mysqli->errno} : {$mysqli->error}</p>";
			exit();
		}
	}
}
?>	















<script src="//maps.googleapis.com/maps/api/js" type="text/javascript"></script>
<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/tether.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-typeahead/bootstrap3-typeahead.min.js"></script>
<script type="text/javascript" src="assets/libraries/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.gmap3.js"></script>
<script type="text/javascript" src="assets/js/jquery.ytplayer.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.ezmark.min.js"></script>
<script type="text/javascript" src="assets/js/eve.js"></script>
</body>
</html>