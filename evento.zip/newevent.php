<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">

    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet" type="text/css">
    <link href="assets/libraries/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/entypo/style.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.min.css" rel="stylesheet" type="text/css">
    <link href="assets/libraries/owl-carousel/owl.carousel.default.css" rel="stylesheet" type="text/css">
    <link href="assets/css/eve.css" rel="stylesheet" type="text/css" id="css-primary">
	<link rel="shortcut icon" type="image/x-icon" href="assets/img/favicon.png">

    <title>Evento. - Home</title>
</head>

<body class="">
<div class="page-wrapper">

	<div class="header-wrapper">
	<div class="header">		
		<div class="header-inner">
			<div class="header-top">
				<div class="container-fluid">
					<div class="header-logo">
						<a href="home.php">
							<span class="eve-logo"><i class="fa fa-edge"></i></span> 
							<strong>
								<span>Evento. </span>
							</strong>
						</a>
					</div><!-- /.header-logo -->

					<!-- /.header-toggle -->
					
					<div class="header-btn">
						<a class="btn btn-secondary" href="newevent.php">Create Event</a><!-- /.btn -->
					</div><!-- /.header-btn -->
					
					<div class="header-search">
						<ul class="nav nav-pills">
			<li class="nav-item">
			<a href="home.php" class="nav-link active">Home</a>
		</li>
		<li class="nav-item"><a href="events.php" class="nav-link ">Events</a></li>
		<li class="nav-item"><a href="contact.php" class="nav-link ">Contact</a></li>
		
		<li class="nav-item"><a href="index.php" class="nav-link ">Logout</a></li>
	</ul>
					</div><!-- /.header-search -->

				</div><!-- /.container-fluid -->
			</div><!-- /.header-top -->

			<!-- /.header-bottom -->
		</div><!-- /.header-inner -->
	</div><!-- /.header -->
</div><!-- /.header-wrapper -->

	<div class="main-wrapper">
	    <div class="main">
	        <div class="main-inner">
	        	
<?php
require_once("db_const.php");
if (!isset($_POST['submit'])) {
?>
	            <div class="content">
	                <div class="container">

	<form method="post" action="newevent.php">		
		<fieldset>
			<legend>Basic Information</legend>		

			<div class="form-group">
				<label>Title</label>
				<input type="text" class="form-control bordered" name="eventTitle">
			</div><!-- /.form-group -->

			<div class="form-group">
				<label>Description</label>
				<textarea class="form-control bordered" rows="2" name="eventDes"></textarea>
			</div><!-- /.form-group -->
		</fieldset>

		<fieldset>
			<legend>Location</legend>

			<div class="row">
				<div class="col-sm-4">
					<div class="form-group">
						<label>Address</label>
						<input type="text" class="form-control bordered" name="location">
					</div><!-- /.form-group -->
				</div><!-- /.col-* -->

					
			</div><!-- /.row -->
		</fieldset>

		<fieldset>
			<legend>Date</legend>

			<div class="row">
			    <div class="col-sm-4">
			        <div class="form-group">
			            <label>Day</label>
			            
			            <select class="form-control bordered" name="day">
			            	
			            	<option value="1">1</option>
			            	<option value="2">2</option>
			            	<option value="3">3</option>
			            	<option value="4">4</option>
			            	<option value="5">5</option>
			            	<option value="6">6</option>
			            	<option value="7">7</option>
			            	<option value="8">8</option>
			            	<option value="9">9</option>
			            	<option value="10">10</option>
			            	<option value="11">11</option>
			            	<option value="12">12</option>
			            	<option value="13">13</option>
			            	<option value="14">14</option>
			            	<option value="15">15</option>
			            	<option value="16">16</option>
			            	<option value="17">17</option>
			            	<option value="18">18</option>
			            	<option value="19">19</option>
			            	<option value="20">20</option>
			            	<option value="21">21</option>
			            	<option value="22">22</option>
			            	<option value="23">23</option>
			            	<option value="24">24</option>
			            	<option value="25">25</option>
			            	<option value="26">26</option>
			            	<option value="27">27</option>
			            	<option value="28">28</option>
			            	<option value="29">29</option
			            	<option value="30">30</option>
			            	<option value="31">31</option>
			            </select>
			        </div><!-- /.form-group -->
			    </div><!-- /.col-* -->

			    <div class="col-sm-4">
			        <div class="form-group">
			            <label>Month</label>
			            <select class="form-control bordered" name="month">
			            <option value="Jan">Jan</option>
			            <option value="Feb">feb</option>
			            <option value="Mar">Mar</option>
			            <option value="Apr">Apr</option>
			            <option value="May">May</option>
			            <option value="Jun">Jun</option>
			            <option value="Jul">Jul</option>
			            <option value="Aug">Aug</option>
			            <option value="Sep">Sep</option>
			            <option value="Oct">Oct</option>
			            <option value="Nov">Nov</option>
			            <option value="Dec">Dec</option>
			     
					</select>
			        </div><!-- /.form-group -->
			    </div><!-- /.col-* -->
			    <div class="col-sm-4">
			        <div class="form-group">
			            <label>Year</label>
			            <select class="form-control bordered" name="year">
			            <option value="2017">2017</option>
			            <option value="2018">2018</option>
			            <option value="2019">2019</option>
			            <option value="2020">2020</option>
			           
			     
					</select>
			        </div><!-- /.form-group -->
			    </div><!-- /.col-* -->

			    
			</div>
		</fieldset>
		<fieldset>
			<legend>Time</legend>

			<div class="row">
				<div class="col-sm-4">
					<div class="form-group">
						<label>Time (Format: HH:MM:SS)</label>
						<input type="text" class="form-control bordered" name="eventTime">
					</div><!-- /.form-group -->
				</div><!-- /.col-* -->

					
			</div><!-- /.row -->
		</fieldset>


		<div class="center">
		<button type="submit" name="submit" value="Login" class="btn btn-secondary pull-right">Create Event</button>
		</div><!-- /.center -->
	</form>
</div><!-- /.container-fluid -->
	            </div><!-- /.content -->
	        </div><!-- /.main-inner -->
	    </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

    <!-- /.here -->
</div><!-- /.card -->
			</div><!-- /.col-* -->
		
	</div><!-- /.row -->
</div><!-- /.container-fluid -->
	            </div><!-- /.content -->
	        </div><!-- /.main-inner -->
	    </div><!-- /.main -->
    </div><!-- /.main-wrapper -->

<?php
} else {
## connect mysql server
	$mysqli = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
	# check connection
	if ($mysqli->connect_errno) {
		echo "<p>MySQL error no {$mysqli->connect_errno} : {$mysqli->connect_error}</p>";
		exit();
	}
## query database
	# prepare data for insertion
	$eventTitle	= $_POST['eventTitle'];
	$eventDes	= $_POST['eventDes'];
	$day = $_POST['day'];
	$month = $_POST['month'];
	$year = $_POST['year'];
	$eventTime	= $_POST['eventTime'];
	$location		= $_POST['location'];


	

	if ($exists == 1) echo "<p></p>";
	else if ($exists == 2) echo "<p></p>";
	else if ($exists == 3) echo "<p></p>";
	else {
		# insert data into mysql database
		$sql = "INSERT  INTO `events` (`id`, `eventTitle`, `eventDes`, `day`, `month`, `year`, `eventTime`, `location`) 
				VALUES (NULL, '{$eventTitle}', '{$eventDes}', '{$day}', '{$month}', '{$year}', '{$eventTime}', '{$location}')";

		if ($mysqli->query($sql)) {
			//echo "New Record has id ".$mysqli->insert_id;
			echo "</br> </br>  <h2>  Your event has been created.</h2>";
		} else {
			echo "<p>MySQL error no {$mysqli->errno} : {$mysqli->error}</p>";
			exit();
		}
	}
}
?>	















<script src="//maps.googleapis.com/maps/api/js" type="text/javascript"></script>
<script type="text/javascript" src="assets/js/jquery.js"></script>
<script type="text/javascript" src="assets/js/tether.min.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/libraries/bootstrap-typeahead/bootstrap3-typeahead.min.js"></script>
<script type="text/javascript" src="assets/libraries/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.gmap3.js"></script>
<script type="text/javascript" src="assets/js/jquery.ytplayer.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.ezmark.min.js"></script>
<script type="text/javascript" src="assets/js/eve.js"></script>
</body>
</html>